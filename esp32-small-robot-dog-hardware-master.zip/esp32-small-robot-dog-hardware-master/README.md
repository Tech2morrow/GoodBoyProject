# Small Robot dog (quadruped) - printable parts

## Disclaimer
**This project has been done mostly for fun about a year ago. Some libraries have been updated, so it basically does not work any more. Not every planned feature was released. No PCB is made and it creates a lot of trouble for most of you. I'm sorry to say, but I'm not going to provide any support for it any more. It's exhausting and sometimes just destroys any intentions to continue. This is not comercial project and I'm not going to do something like Donation. Maybe I'm disappointing someone. Sorry. Project closed.**

## Files
 - body/ - small dog body parts
 - tools/ - some helpers, calibrate servo and legs
