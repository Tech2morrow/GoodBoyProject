# Robot dog web interface

## Build
 - `npm install` - install node.js packages
 - `npm run build` - build web interface
