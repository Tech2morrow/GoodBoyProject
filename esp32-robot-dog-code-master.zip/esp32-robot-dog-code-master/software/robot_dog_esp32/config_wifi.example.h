// First credentials for Access point (AP) mode
const char* wifiSsid[] = {"APssid", "ssid1", "ssid2"};
const char* wifiPass[] = {"APpass", "123",   "456"};
