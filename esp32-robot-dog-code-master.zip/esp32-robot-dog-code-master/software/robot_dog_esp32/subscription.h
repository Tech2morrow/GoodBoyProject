
const typedef struct subscription_t {
  mutable bool fast;
  mutable bool active;
} subscription;
